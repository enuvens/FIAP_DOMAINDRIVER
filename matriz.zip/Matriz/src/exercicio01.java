
public class exercicio01 {

	public static void main(String[] args) {

		int matriz[][] = new int[5][6];
		String mensagem = "";

		//System.out.println(matriz.length);
		for (int l = 0; l < 5; l++){
			for (int c = 0; c < 6; c++){
				if (c % 2 == 0){
					matriz[l][c] = 0;
				} else {
					matriz[l][c] = 1;
				}
				mensagem += matriz[l][c];
				if (c == 5){
					mensagem += "\n";
				}
			}
		}
		System.out.println(mensagem);
	}

}
