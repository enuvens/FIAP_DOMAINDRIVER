
public class exercicio03 {

	public static void main(String[] args) {

		int matriz[][] = new int[5][5];
		String mensagem = "";
		
		//System.out.println(matriz.length);
		for (int l = 0; l < 5; l++){
			for (int c = 0; c < 5; c++){
				if (l == c){
					matriz[l][c] = 1;
				} else {
					matriz[l][c] = 0;
				}
				mensagem += matriz[l][c];
				if (c == 4){
					mensagem += "\n";
				}
			}
		}
		System.out.println(mensagem);
	}

}
