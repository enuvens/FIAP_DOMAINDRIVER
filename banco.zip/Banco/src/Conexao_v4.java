import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Conexao_v4 {

	public static void main(String[] args) {
		Connection conectar = null;
		PreparedStatement estrutura = null;
		ResultSet resultado = null;

		try{
			conectar = DriverManager.getConnection("jdbc:oracle:thin:@oracle.fiap.com.br:1521:ORCL", "RM78582", "130483");
			estrutura = conectar.prepareStatement("SELECT NM_CLIENTE, NR_CLIENTE, QT_ESTRELAS FROM TB_DDD_CLIENTE WHERE NM_CLIENTE LIKE '%o'");
			resultado = estrutura.executeQuery();
			
			while(resultado.next()){
				System.out.println("\nCliente: "
						+ resultado.getString("NM_CLIENTE")
						+" ["+ resultado.getString("NR_CLIENTE") +"]");
			}
		} catch (SQLException e){
			e.printStackTrace();
		} finally {
			try{
				resultado.close();
				estrutura.close();
				conectar.close();
			} catch(SQLException e){
				e.printStackTrace();
			}
		}

	}

}
